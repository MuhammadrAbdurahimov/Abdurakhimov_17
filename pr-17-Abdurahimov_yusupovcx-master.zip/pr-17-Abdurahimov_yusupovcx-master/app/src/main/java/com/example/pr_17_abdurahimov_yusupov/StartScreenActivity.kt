package com.example.pr_17_abdurahimov_yusupov

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions

class StartScreenActivity : AppCompatActivity(), OnMapReadyCallback {
    private lateinit var map: GoogleMap

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_start_screen)

        // Инициализация карты
        val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap

        // Добавление маркера на карту
        val location = LatLng(55.7558, 37.6173) // Москва
        map.addMarker(MarkerOptions().position(location).title("Москва"))
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 10f))
    }
    val menuButton: Button = findViewById(R.id.menuButton)
    menuButton.setOnClickListener {
        val intent = Intent(this, MenusActivity::class.java)
        startActivity(intent)
    }
    al intent = Intent(this, NextActivity::class.java)
    startActivity(intent)

}